import os, sys
import pygame
import pygame.transform
from game.registry import adjpos, adjrect, adjwidth, adjheight

# Game parameters
SCREEN_WIDTH, SCREEN_HEIGHT = adjpos (800, 500)
TITLE = "Symons Media: Duck Hunt"
FRAMES_PER_SEC = 50
BG_COLOR = 255, 255, 255

# Initialize pygame before importing modules
pygame.mixer.pre_init(44100, -16, 2, 1024)
pygame.init()
pygame.display.set_caption(TITLE)
pygame.mouse.set_visible(False)

import game.driver
import thread
import time

import cv2, math, cv
import numpy as np
import Queue


class ColourTracker:
  def nothing(*arg):
    pass
    
  def __init__(self,in_queue, out_queue):
    cv2.namedWindow("ColourTrackerWindow", cv2.CV_WINDOW_AUTOSIZE)
    self.capture = cv2.VideoCapture(0)
    self.capture.set(6, 60)
    self.scale_down = 1
    self.in_queue = in_queue
    self.out_queue = out_queue
    
  def run(self):
    cv2.namedWindow('view')
    v = np.loadtxt('sliders.txt')
    
    cv2.createTrackbar('H1', 'view', 0, 254, self.nothing)
    cv2.setTrackbarPos('H1', 'view', int(v[0]))
    cv2.createTrackbar('H2', 'view', 1, 255, self.nothing)
    cv2.setTrackbarPos('H2', 'view', int(v[1]))
    cv2.createTrackbar('S1', 'view', 0, 254, self.nothing)
    cv2.setTrackbarPos('S1', 'view', int(v[2]))
    cv2.createTrackbar('S2', 'view', 1, 255, self.nothing)
    cv2.setTrackbarPos('S2', 'view', int(v[3]))
    cv2.createTrackbar('B1', 'view', 0, 254, self.nothing)
    cv2.setTrackbarPos('B1', 'view', int(v[4]))
    cv2.createTrackbar('B2', 'view', 1, 255, self.nothing)
    cv2.setTrackbarPos('B2', 'view', int(v[5]))
    
    
    while True:
      f, orig_img = self.capture.read()
      #orig_img = cv2.flip(orig_img, 1)
      img = cv2.GaussianBlur(orig_img, (5,5), 0)
      img = cv2.cvtColor(orig_img, cv2.COLOR_BGR2HSV)
      img = cv2.resize(img, (len(orig_img[0]) / self.scale_down, len(orig_img) / self.scale_down))

      H1 = cv2.getTrackbarPos('H1', 'view')
      H2 = cv2.getTrackbarPos('H2', 'view')
      S1 = cv2.getTrackbarPos('S1', 'view')
      S2 = cv2.getTrackbarPos('S2', 'view')
      B1 = cv2.getTrackbarPos('B1', 'view')
      B2 = cv2.getTrackbarPos('B2', 'view')
      
      data = [H1, H2, S1, S2, B1, B2]
      np.savetxt('sliders.txt', data)

      red_lower = np.array([H1, S1, B1],np.uint8)
      red_upper = np.array([H2, S2, B2],np.uint8)
      red_binary = cv2.inRange(img, red_lower, red_upper)

      
      
      dilation = np.ones((50, 50), "uint8")
      red_binary = cv2.dilate(red_binary, dilation)
      erosion = np.ones((40, 40), "uint8")
      red_binary = cv2.erode(red_binary, erosion)
      cv2.imshow("thr", red_binary)
      contours, hierarchy = cv2.findContours(red_binary, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
      max_area = 0
      largest_contour = None
      cv2.imshow("view", orig_img)
      for idx, contour in enumerate(contours):
        area = cv2.contourArea(contour)
        if area > max_area:
          max_area = area
          largest_contour = contour
      if not largest_contour == None:
        moment = cv2.moments(largest_contour)
        if moment["m00"] > 100 / self.scale_down:
          rect = cv2.minAreaRect(largest_contour)
          rect = ((rect[0][0] * self.scale_down, rect[0][1] * self.scale_down), (rect[1][0] * self.scale_down, rect[1][1] * self.scale_down), rect[2])
          box = cv2.cv.BoxPoints(rect)
          box = np.int0(box)
          #print(box)
          A = box[1][0]
          
          B = box[2][0]
          C = box[0][1]
          D = box[3][1]
          center = [0,0]
          center[0] = box[0][0] + (A - B)/2
          center[1] = box[0][1] + (C - D)/2 
          #center = [box[0][0],box[0][1]]
          
          self.out_queue.put(center)

        #  self.in_queue.task_done()
          
          cv2.drawContours(orig_img,[box], 0, (0, 0, 255), 2)
          cv2.imshow("ColourTrackerWindow", orig_img)
      if cv2.waitKey(1) == 27:
           cv2.destroyWindow("ColourTrackerWindow")
           self.capture.release()
           break



class Game(object):
    def __init__(self):
        self.running = True
        self.surface = None
        self.clock = pygame.time.Clock()
        self.size = SCREEN_WIDTH, SCREEN_HEIGHT
        background = os.path.join('media', 'background.jpg')
        bg = pygame.image.load(background)
        self.background = pygame.transform.smoothscale (bg, self.size)
        self.driver = None

    def init(self):
        self.surface = pygame.display.set_mode(self.size)
        self.driver = game.driver.Driver(self.surface)

    def handleEvent(self, event):
        #if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key is 27):
        #    self.running = False
        #else:
        self.driver.handleEvent(event)

    def loop(self):
        self.clock.tick(FRAMES_PER_SEC)
        self.driver.update()

    def render(self):
        self.surface.blit(self.background, (0,0))
        self.driver.render()
        pygame.display.flip()

    def cleanup(self):
        pygame.quit()
        sys.exit(0)


    def execute(self):
        self.init()
        self.in_queue = Queue.Queue()
        self.out_queue = Queue.Queue()
        colour_tracker = ColourTracker(self.in_queue, self.out_queue)
        thread.start_new_thread(colour_tracker.run,())
        

        while (self.running):
            for otherEvent in pygame.event.get():
                print("other event")
                if otherEvent.type == pygame.QUIT or (otherEvent.type == pygame.KEYDOWN and otherEvent.key is 27):
                    print("esc")
                    self.running = False
                if (otherEvent.type == pygame.KEYDOWN and otherEvent.key is 32):
                    print("spacebar")
                    self.handleEvent([10000,10000])
                if (otherEvent.type == pygame.KEYDOWN and otherEvent.key is 114):
                    
                    theGame = Game()
                    theGame.execute()
                    
            try:
                self.loop()
                self.render()
                item = self.out_queue.get(True, 0.005)
                #self.out_queue.task_done()
                #homography = [[  1.46972249e+00 ,  1.28387508e-01 , -8.15546104e+00],
                #[ -7.58788694e-03 ,  1.52139852e+00 , -8.86766749e+00],
                #[  5.61283438e-05  , 1.82724924e-04 ,  1.00000000e+00]]
                homography = np.loadtxt('H.txt')


                point = [0, 0, 0]
                point[0] = item[0]
                point[1] = item[1]
                point[2] = 1
                newPoint = np.dot(homography, point)
                
                newPoint = newPoint / newPoint[2]
                item[0] = newPoint[0]
                item[1] = newPoint[1] - 35
                
                
                self.handleEvent(item)
                print(item[1])
            except Queue.Empty as e:
                continue
                
            

            
        self.cleanup()


if __name__ == "__main__":
    theGame = Game()
    theGame.execute()
