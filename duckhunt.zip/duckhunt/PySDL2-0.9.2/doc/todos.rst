Todo list for PySDL2
====================

General
-------
* more unit tests
