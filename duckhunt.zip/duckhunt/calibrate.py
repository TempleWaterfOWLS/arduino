#!/usr/bin/python
import cv
import sys
import urllib2
import cv2, math, cv
import numpy as np
  
    
class Calibrator:
 
    def nothing(*arg):
        pass
     
    def __init__(self):
        cv2.namedWindow("ColourTrackerWindow", cv2.CV_WINDOW_AUTOSIZE)
        self.capture = cv2.VideoCapture(0)
        self.capture.set(6, 60)
        self.scale_down = 1

        
        cv.NamedWindow("win")
        
        #filename = sys.argv[1]
        self.im = cv.LoadImage("chess.jpg", cv.CV_LOAD_IMAGE_GRAYSCALE)
        self.im3 = cv.LoadImage("chess.jpg", cv.CV_LOAD_IMAGE_COLOR)
        
        self.chessboard_dim = ( 9, 6 )
       
        self.found_all, self.screenCorners = cv.FindChessboardCorners( self.im, self.chessboard_dim )
        print self.found_all, len(self.screenCorners)

        #cv.DrawChessboardCorners( self.im3, self.chessboard_dim, self.corners, self.found_all )
       
        cv.ShowImage("win", self.im3);
        cv.WaitKey(1)
        
    def run(self):
        cv2.namedWindow('view')
        cv2.namedWindow('warped')
        cv2.createTrackbar('H1', 'view', 0, 254, self.nothing)
        cv2.createTrackbar('H2', 'view', 1, 255, self.nothing)
        cv2.createTrackbar('S1', 'view', 0, 254, self.nothing)
        cv2.createTrackbar('S2', 'view', 1, 255, self.nothing)
        cv2.createTrackbar('B1', 'view', 0, 254, self.nothing)
        cv2.createTrackbar('B2', 'view', 1, 255, self.nothing)
        while True:
          f, orig_img = self.capture.read()
          #orig_img = cv2.flip(orig_img, 1)
          img = cv2.GaussianBlur(orig_img, (5,5), 0)
          img = cv2.cvtColor(orig_img, cv2.COLOR_BGR2HSV)
          img = cv2.resize(img, (len(orig_img[0]) / self.scale_down, len(orig_img) / self.scale_down))

          H1 = cv2.getTrackbarPos('H1', 'view')
          H2 = cv2.getTrackbarPos('H2', 'view')
          S1 = cv2.getTrackbarPos('S1', 'view')
          S2 = cv2.getTrackbarPos('S2', 'view')
          B1 = cv2.getTrackbarPos('B1', 'view')
          B2 = cv2.getTrackbarPos('B2', 'view')
          red_lower = np.array([H1, S1, B1],np.uint8)
          red_upper = np.array([H2, S2, B2],np.uint8)
          red_binary = cv2.inRange(img, red_lower, red_upper)

          
          
          cv2.imshow("view", orig_img)
          
          chessboard_dim = ( 9, 6 )
          orig_img = cv.fromarray(orig_img)
          
          found_all, camCorners = cv.FindChessboardCorners(orig_img, chessboard_dim )
          if found_all :
              print found_all, len(camCorners)
              #print(self.screenCorners)
              cv.DrawChessboardCorners( orig_img, chessboard_dim, camCorners, found_all )
              homography , mask = cv2.findHomography(np.array(camCorners,dtype=np.float32),np.array(self.screenCorners,dtype=np.float32) )
              print(homography)
              np.savetxt('H.txt', homography)
              point = [[1],[1], [1]]
              newPoint = np.dot(homography, point)
              print(newPoint / newPoint[2])
              warp_img = cv2.warpPerspective(np.array(orig_img,dtype=np.float32), homography, (800,500))
              warp_img = np.asarray( warp_img[:,:] ) 
              cv2.imshow("warped", warp_img) 
          orig_img = np.asarray( orig_img[:,:] )    
          cv2.imshow("view", orig_img)
          
          if cv2.waitKey(1) == 27:
               cv2.destroyWindow("ColourTrackerWindow")
               self.capture.release()
               break
           
           
if __name__ == "__main__":
  calibrator = Calibrator()
  calibrator.run()
