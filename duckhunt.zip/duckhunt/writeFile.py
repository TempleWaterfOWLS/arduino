import numpy as np

homography = [[  1.46972249e+00 ,  1.28387508e-01 , -8.15546104e+00],
[ -7.58788694e-03 ,  1.52139852e+00 , -8.86766749e+00],
[  5.61283438e-05  , 1.82724924e-04 ,  1.00000000e+00]]

 
np.savetxt('H.txt', homography)

homography = np.loadtxt('H.txt')

# Note that this returned a 2D array!
print homography.shape
print homography


H1 = 55
H2 = 66
S1 = 77
S2 = 88
B1 = 99
B2 = 100

data = [H1, H2, S1, S2, B1, B2]
np.savetxt('sliders.txt', data)

data2 = np.loadtxt('sliders.txt')

print data[1]
